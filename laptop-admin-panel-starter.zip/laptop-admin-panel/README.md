# Laptop Admin Panel

Starter admin panel bertema putih-hitam untuk inventaris laptop dan generator iklan Facebook Marketplace.

## Setup
1. Buat project di Supabase.
2. Jalankan `supabase/schema.sql` di SQL Editor.
3. Aktifkan Email login dan buat akun admin di Authentication > Users.
4. Salin `.env.example` menjadi `.env.local`, lalu isi URL dan anon/publishable key Supabase. Jangan gunakan service-role key di frontend.
5. Perlu Node.js 20+. Jalankan `npm install`, lalu `npm run dev`.
6. Buka alamat yang muncul di terminal.

## Deploy
Upload isi folder ke repository GitHub, import repository ke Vercel, dan masukkan dua environment variable Supabase di pengaturan Vercel.

## Catatan
Import PDF pada versi awal hanya mengekstrak teks PDF digital dan membuat draft untuk ditinjau. Format PDF supplier harus diuji agar parser lebih akurat. PDF hasil scan mungkin perlu OCR. Data tidak otomatis masuk inventaris hanya karena terdeteksi di PDF. Produk yang tidak muncul pada PDF terbaru tidak otomatis dianggap terjual.

Contoh SQL RLS ini mengizinkan semua user yang sudah login mengakses tabel. Buat hanya akun admin yang tepercaya atau perketat policy sebelum menambahkan pengguna lain.
