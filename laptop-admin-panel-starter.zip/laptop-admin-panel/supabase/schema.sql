create extension if not exists pgcrypto;
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(),
 brand text not null default '', model text not null default '',
 processor text not null default '', ram text not null default '', storage text not null default '',
 condition_notes text not null default '', supplier_price integer not null default 0 check (supplier_price >= 0),
 markup integer not null default 300000, calculated_price integer not null default 300000, manual_price integer,
 status text not null default 'available' check(status in ('available','reserved','sold','archived')),
 posting_status text not null default 'not_posted' check(posting_status in ('not_posted','posted')),
 notes text not null default '', created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.price_history (
 id uuid primary key default gen_random_uuid(), product_id uuid references public.products(id) on delete set null,
 supplier_price integer not null, calculated_price integer not null, manual_price integer, created_at timestamptz not null default now()
);
alter table public.products enable row level security;
alter table public.price_history enable row level security;
drop policy if exists "Authenticated users manage products" on public.products;
create policy "Authenticated users manage products" on public.products for all to authenticated using (true) with check (true);
drop policy if exists "Authenticated users manage price history" on public.price_history;
create policy "Authenticated users manage price history" on public.price_history for all to authenticated using (true) with check (true);
